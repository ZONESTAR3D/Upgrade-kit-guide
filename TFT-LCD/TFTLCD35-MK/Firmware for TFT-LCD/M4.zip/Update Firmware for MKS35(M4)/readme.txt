2020-4-27  V：0.1.5  First issue
2020-6-24  V：0.1.6  Modify abnormal display of hotbed temperature and other bugs
2020-7-29  V：0.1.6  Modify leveling picture in mks_pic file. Change manual leveling to automatic leveling.
2020-10-28  V：1.0.0  
1.Modify the problem of slow refresh of temperature display,and several other bugs.
2.Add babystep function.
3.Modify the menu operation mode of mixed color printing.
4.The multi-color extrusion options are added through the configuration file, and up to 4 colors can be selected.
2020-10-28  V：1.0.1
Redefine the leveling function. 
2020-11-03  V：1.0.2
Modify the problem of power interruption and continuation.
2020-11-04  V：1.0.3
Modify power off and continue function.
2020-11-04  V：1.0.4
Fix temperature display bug.
